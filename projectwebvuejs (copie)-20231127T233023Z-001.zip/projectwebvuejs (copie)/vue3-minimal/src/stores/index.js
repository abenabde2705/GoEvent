import { defineStore } from 'pinia'
import axios from 'axios'
export const useDefaultStore = defineStore({
  id: 'default',
  state: () => ({
    "categories":[],
    "evenements":[]
   //{"id":1,"nom":"boxe","evenements":[],"image":"gloves.jpg"}
  }),
  getters: {
    
  },
  actions: {
    loadData() {
      axios.get('http://127.0.0.1:8000/api/categories.json')
      .then(response => response.data)
      .then(donneesQuizs => this.categories = donneesQuizs)
  },
  loadData2() {
    axios.get('http://127.0.0.1:8000/api/evenements.json')
    .then(response => response.data)
    .then(donneesQuizs => this.evenements = donneesQuizs)
}
  
}
})
