<template>
 <div class="example-wrapper">
    <h1 class="main_h1">Create a new Event: </h1>
    <div class="hero">
      <form @submit="submitForm">
        <div class="form-group">
          <label for="titre">Titre:</label>
          <input type="text" id="titre" v-model="form.titre" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="categories">Categories:</label>
          <select id="categories" v-model="form.categories" class="form-control" multiple required>
  <option v-for="item in store.categories" :value="item.id" :key="item.id">{{ item.nom }}</option>
</select>

        </div>
        <div class="form-group">
          <label for="description">Description:</label>
          <textarea id="description" v-model="form.description" class="form-control" required></textarea>
        </div>
        <div class="form-group">
          <label for="datedebut">Date de début:</label>
          <input type="date" id="datedebut" v-model="form.datedebut" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="datefin">Date de fin:</label>
          <input type="date" id="datefin" v-model="form.datefin" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="localisation">Localisation:</label>
          <input type="text" id="localisation" v-model="form.localisation" class="form-control" required>
        </div>
        <div class="form-group">
          <label for="photo">Load your image here:</label>
          <input type="file" id="photo" class="form-control-file" @change="handleFileUpload">
        </div>
        <button type="submit" class="btn1 btn-primary1">Submit</button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import axios from 'axios';
import { useDefaultStore } from '../stores/index.js';
import {onMounted} from 'vue';

const store = useDefaultStore();

// Définissez les données réactives
const form = ref({
  titre: '',
  categories: [],
  description: '',
  datedebut: '',
  datefin: '',
  localisation: '',
  photo: null,
});
const categories = ref([]);


// Méthode pour soumettre le formulaire
const submitForm = async (event) => {
  event.preventDefault();
  
  // Créez un objet FormData pour envoyer les données
  const formData = new FormData();
  formData.append('titre', form.titre);
  // Ajoutez les autres champs du formulaire à formData

  // Vérifiez si une photo a été sélectionnée
  if (form.photo) {
    formData.append('photo', form.photo, form.photo.name);
  }

  try {
    // Utilisez Axios pour envoyer les données à Symfony
    const response = await axios.post('/path/to/symfony/endpoint', formData);
    console.log(response.data); // Affichez la réponse de Symfony
    // Réinitialisez les champs du formulaire après la soumission réussie
    form.value = {
      titre: '',
      categories: [],
      description: '',
      datedebut: '',
      datefin: '',
      localisation: '',
      photo: null,
    };
  } catch (error) {
    console.error(error); // Affichez les erreurs éventuelles
  }
};

// Méthode pour gérer l'upload de fichier
const handleFileUpload = (event) => {
  const file = event.target.files[0];
  form.photo = file;
};</script>

<style scoped>
.example-wrapper {
    margin: 1em auto;
  max-width: 800px;
  width: 95%;
  font: 18px/1.5 sans-serif;
  background-color: rgba(128, 128, 128, 0.2);
  padding: 20px;
}

.example-wrapper code {
  background: #F5F5F5;
  padding: 2px 6px;
}

.main_h1 {
    text-align: center;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    color: #afb5eb;
    font-size: 28px;
    margin-bottom: 20px;
}

.hero {
  margin-top: 20px;
}

.form-control {
  width: 100%;
  padding: 10px;
  font-size: 16px;
  border-radius: 4px;
  border: 1px solid #ccc;
}

.form-control-file {
  margin-top: 10px;
}

.btn1 {
  background-color: #4CAF50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.btn-primary1 {
  background-color: #007bff;
}

</style>