<template>
  <div class="contenu">
<h2>Our Events</h2>


<div class="categories">
    <div class="category" v-bind:key="item.id" v-for="item in store.evenements">
      <div class="category-box">
        <div class="event-image">
          <img src="../../public/image/background.jpg">
        </div>
        <div class="event-details">
          <h3 class="event-title">{{ item.titre }}</h3>
          <ul>
            <li class="event-description">{{ item.description }}</li>
            <li class="event-location">
              <i class="fas fa-map-marker-alt"></i> {{ item.localisation }}
            </li>
            <li class="event-date">
              <i class="far fa-calendar-alt"></i>
              {{ item.datedebut }} - {{ item.datefin }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
</template>
<script setup>
import { useDefaultStore } from '../stores/index.js';
import {onMounted,ref} from 'vue';

const store = useDefaultStore();


</script>
<style scoped>
.contenu{
  min-height: calc(250vh - 160px);
}
h2 {
  color: #afb5eb;
  font-size: 40px;
  text-align: center;
  margin-top: 40px;
  font-family: "Arial", sans-serif;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 2px;
}

.categories {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}



.category:before,
.category:after {
  content: '';
  position: absolute;
  width: 0;
  height: 100%;
  border: 2px solid transparent;
  transition: width 0.3s ease;
}

.category:before {
  left: 0;
  top: 0;
}

.category:after {
  right: 0;
  bottom: 0;
}


.event-image {
  position: relative;
  height: 200px;
  overflow: hidden;
}

.event-image img {
  width: 100%;
  height: auto;
  object-fit: cover;
}
.category {
  margin: 10px;
  width: 300px;
  height: 400px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
  border: 2px solid #1f2029;
  position: relative;
  transition: border-color 0.3s ease;
}
.category:hover {
  transform: scale(1.05); /* Agrandit l'élément de 5% */
  background-color: rgba(0, 0, 0, 0.1); /* Assombrit légèrement la couleur de fond */
  transition: transform 0.3s ease, background-color 0.3s ease; /* Ajoute une transition fluide */
  border-color: #6b6b6b
}

.category:hover:before,
.category:hover:after {
  /* Anime l'élargissement de la bordure au survol */
  width: 100%;
}
.event-image {
  height: 200px;
  background-size: cover;
  background-position: center;
}


.event-details {
  padding: 20px;
}

.event-title {
  font-size: 18px;
  margin-top: 0;
  margin-bottom: 10px;
  color: #b4b4b4;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

.event-description {
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease, opacity 0.3s ease;
  }

  .category:hover .event-description {
    /* Affiche la description au survol */
    opacity: 1;
    max-height: 100px; /* Ajustez cette valeur en fonction de votre besoin */
    margin-top: 10px; /* Ajoute une marge au-dessus de la description */
  }

.event-location,
.event-date {
  font-size: 14px;
  color: #6b6b6b;
  margin-bottom: 5px;
}

.event-location i,
.event-date i {
  margin-right: 5px;
}

ul {
  margin: 0;
  padding: 0;
  list-style: none;
}

li {
  margin-bottom: 10px;
}

.fa-map-marker-alt,
.fa-calendar-alt {
  margin-right: 5px;
  color: #b4b4b4;
}

@media (max-width: 600px) {
  .category {
    width: 100%;
  }
}
</style>