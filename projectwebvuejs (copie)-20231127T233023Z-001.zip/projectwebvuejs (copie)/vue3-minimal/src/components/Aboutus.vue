<template>
  <div>
     <h1 class="main_h1">Our Concept</h1>
      <!--  <router-link to="/categories"> nos categories</router-link>
       <p></p>-->
       <section class="paragraphsau">


           <section>
               <h2>Welcome:</h2>
               <p>Welcome to Go event! We are a team of experienced event planners who are dedicated to creating memorable experiences for our clients. Our goal is to make the planning process stress-free and enjoyable.</p>
           </section>

           <section class="team-section">
               <h2>Team:</h2>
               <p>Our team has years of experience in the event planning industry and we pride ourselves on our attention to detail and ability to turn our clients' visions into reality. We work closely with each client to tailor our services to their specific needs.</p>
           </section>

           <section>
               <h2>Thanks:</h2>
               <p>We believe that communication is key to a successful event, which is why we work closely with our clients throughout the planning process. Our services range from event design and planning to day-of coordination and everything in between. Contact us today to learn more about how we can bring your event to life.</p>
           </section>
       </section>
       </div>
</template>
<script setup>
import { useDefaultStore } from '../stores/index.js'
import { onMounted } from 'vue';
const store= useDefaultStore();

onMounted(() => store.loadData());


</script>
<style scoped>

.paragraphsau {
  display:flexbox;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 4rem;
  color: rgb(233, 233, 228);
}

.paragraphsau > section {
  text-align: center;
  padding: 20px;
  margin: 10px;
  width: auto;
  font-size: 1.2rem;
  font-family: "Montserrat", sans-serif;
  background-color: rgba(45, 61, 55, 0.8);
  border-radius: 10px;
  transition: background-color 0.3s ease;
  cursor: pointer;
}

.paragraphsau > section:hover {
  background-color: #afb5eb;
  
}
.team-section {
  margin-top: 2rem;
}

.team-section > h2 {
  margin-bottom: 0.5rem;
}

.team-section > p {
  margin-top: 0.5rem;
}


.main_h1 {
   color: #afb5eb;
  font-size: 40px;
  text-align: center;
  margin-top: 40px;
  font-family: "Arial", sans-serif;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 2px;
}
</style>