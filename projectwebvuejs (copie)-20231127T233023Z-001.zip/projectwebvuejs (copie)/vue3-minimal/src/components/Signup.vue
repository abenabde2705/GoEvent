<template>
   <div class="flex-container">
    <div class="content-container">
      <div class="form-container">
        <form action="process_signup.php" method="POST">
          <h1>Signup</h1>
          <br>
          <br>
          <span class="subtitle">First Name:</span>
          <br>
          <input type="text" id="firstname" name="firstname" required value="">
          <br>
          <span class="subtitle">Last Name:</span>
          <br>
          <input type="text" id="lastname" name="lastname" required value="">
          <br>
          <span class="subtitle">Address:</span>
          <br>
          <input type="text" id="address" name="address" required value="">
          <br>
          <span class="subtitle">Date of Birth:</span>
          <br>
          <input type="date" id="birthdate" name="birthdate" required value="">
          <br>
          <span class="subtitle">Email:</span>
          <br>
          <input type="email" id="email" name="email" required value="">
          <br>
          <span class="subtitle">Password:</span>
          <br>
          <input type="password" id="password" name="password" required value="">
          <br>
          <br>
          <input type="submit" value="Sign Up" class="submit-btn">
        </form>
     <router-link to="/login">   <p class="new-user-text">You are already member? <a href="login" class="sign-in-link">Log in</a></p></router-link>
      </div>
    </div>
  </div></template>
<script setup>
import {RouterView} from 'vue-router'
</script>
<style scoped>
  .new-user-text {
    margin-top: 20px;
    text-align: center;
    color: #f8f8f8;
  }

  .sign-in-link {
    color: #38d39f;
    text-decoration: none;
  }

  .sign-in-link:hover {
    text-decoration: underline;
  }

  h1 {
    font-size: 24px;
    color: #f8f8f8;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 20px;
  }

  .flex-container {
    width: 100vw;
    margin-top: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .content-container {
    width: 500px;
    height: 350px;
  }

  .form-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 500px;
    height: 350px;
    margin-top: 5px;
    padding-top: 20px;
    min-height: 80vh;
    border-radius: 12px;
    display: flex;
    justify-content: center;
    flex-direction: column;
    background: #1f1f1f;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.199);
  }

  .subtitle {
    font-size: 11px;
    color: rgba(177, 177, 177, 0.3);
  }

  input {
    border: none;
    border-bottom: solid rgb(143, 143, 143) 1px;
    margin-bottom: 30px;
    background: none;
    color: rgba(255, 255, 255, 0.555);
    height: 35px;
    width: 300px;
    transition: border-color 0.3s;
  }

  input:focus {
    outline: none;
    border-color: #38d39f;
  }

  .submit-btn {
    cursor: pointer;
    border: none;
    border-radius: 8px;
    box-shadow: 2px 2px 7px #38d39f70;
    background: #38d39f;
    color: rgba(255, 255, 255, 0.8);
    width: 80px;
    transition: all 0.3s;
  }

  .submit-btn:hover {
    color: rgb(255, 255, 255);
    box-shadow: none;
    transform: scale(1.1);
  }

  .form-container:hover input {
    border-color: #38d39f;
  }
</style>