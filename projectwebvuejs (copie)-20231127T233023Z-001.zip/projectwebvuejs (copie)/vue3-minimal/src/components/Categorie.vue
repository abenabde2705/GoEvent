<template>
<h2>Our Event's categories</h2>


    <div class="categories">
    <div class="category" v-bind:key="item.id" v-for="item in store.categories">
        <div class="category-box">
  <img :src="'/image/'+item.image" alt="Image de la catégorie">
</div>
        <span class="category-name">{{ item.nom }}</span>
      </div>
    </div>
</template>

<script setup>
import { useDefaultStore } from '../stores/index.js';
import {onMounted,ref} from 'vue';

const store = useDefaultStore();


</script>
<style scoped>
  h2{
    text-align: center;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    color: #afb5eb;
    font-size: 28px;
    margin-bottom: 20px;
  }

  .categories {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }

  .category {
    margin: 10px;
  }

  .category-box {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 200px;
    height: 200px;
    background-size: cover;
    background-position: center;
    color: white;
    font-size: 20px;
    text-align: center;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
  }

  .category-box img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .category-name {
    background-color: rgba(241, 241, 241, 0.5);
    padding: 10px;
    font-size: 16px;
    font-weight: bold;
  }
</style>