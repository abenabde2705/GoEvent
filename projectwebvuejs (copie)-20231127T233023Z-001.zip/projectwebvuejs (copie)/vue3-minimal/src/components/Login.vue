<template>
<div class="flex-container">
  <div class="content-container">
    <div class="form-container">
      <form action="/action_page.php">
        <h1>
          Login
        </h1>
        <br>
        <br>
        <span class="subtitle">USERNAME:</span>
        <br>
        <input type="text" name="username" value="">
        <br>
        <span class="subtitle">PASSWORD:</span>
        <br>
        <input type="password" name="password" value="">
        <br><br>
        <input type="submit" value="SUBMIT" class="submit-btn">
      </form>
    <router-link to="/signup">  <p class="new-user-text">You are new? <a href="" class="sign-in-link">Sign up</a></p></router-link>

    </div>
  </div>
</div>
</template>
<script setup>
import {RouterView} from 'vue-router'
</script>
<style scoped>
 .new-user-text {
    margin-top: 20px;
    text-align: center;
    color: #f8f8f8;
  }

  .sign-in-link {
    color: #38d39f;
    text-decoration: none;
  }

  .sign-in-link:hover {
    text-decoration: underline;
  }
h1 {
  font-size: 24px;
  color: #f8f8f8;
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 2px;
  margin-bottom: 20px;
}

.flex-container {
    position: fixed;
  width: 100vw;
  margin-top: 60px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.content-container {
  width: 500px;
  height: 350px;
}

.form-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 500px;
  height: 350px;
  margin-top: 5px;
  padding-top: 20px;
  border-radius: 12px;
  display: flex;
  justify-content: center;
  flex-direction: column;
  background: #1f1f1f;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.199);
}

.subtitle {
  font-size: 11px;
  color: rgba(177, 177, 177, 0.3);
}

input {
  border: none;
  border-bottom: solid rgb(143, 143, 143) 1px;
  margin-bottom: 30px;
  background: none;
  color: rgba(255, 255, 255, 0.555);
  height: 35px;
  width: 300px;
  transition: border-color 0.3s;
}

input:focus {
  outline: none;
  border-color: #38d39f; /* Couleur de bordure lorsqu'un champ est sélectionné */
}

.submit-btn {
  cursor: pointer;
  border: none;
  border-radius: 8px;
  box-shadow: 2px 2px 7px #38d39f70;
  background: #38d39f;
  color: rgba(255, 255, 255, 0.8);
  width: 80px;
  transition: all 0.3s;
}

.submit-btn:hover {
  color: rgb(255, 255, 255);
  box-shadow: none;
  transform: scale(1.1); /* Agrandir légèrement le bouton au survol */
}

.form-container:hover input {
  border-color: #38d39f; /* Changer la couleur de bordure des champs au survol du formulaire */
}

</style>