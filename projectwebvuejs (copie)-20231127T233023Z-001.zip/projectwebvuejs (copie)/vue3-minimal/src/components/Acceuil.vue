<template>
  <div class="page">
    
<h1>Create, Manage, and Share Your Events with Ease.

</h1>
<section class="main-section">

    <p> "Welcome to GoEvent, the platform that allows you to create and organize your events with ease. From planning to management, we provide you with all the tools you need to make your event a memorable success" </p>
  <router-link to="/create"><button>Create an Event</button></router-link>  
</section>
<section class="category">

<router-link to="/categories"  class="button-link"> <h2>Categories</h2></router-link>
<router-link to="/events" class="button-link">
        <h2>Events</h2>
      </router-link>
</section>
</div>
</template>
<script>

</script>
<style scoped>
.page {
  
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}


h1 {
  color: #afb5eb;
  font-size: 40px;
  text-align: center;
  margin-top: 40px;
  font-family: "Arial", sans-serif;
  font-weight: bold;
  text-transform: uppercase;
  letter-spacing: 2px;
}
.main-section {
  max-width: 800px;
  margin: 0 auto;
  padding: 40px;
  margin-top: 100px;
  background-color:  #8c9092;
  border-radius: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}


p {
  color: #302f2f;
  font-size: 18px;
  margin-bottom: 20px;
font-family:monospace
}

button {
  background-color: #0d1f36;
  color: rgb(227, 231, 233);
  padding: 10px 20px;
  font-size: 16px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

button:hover {
  background-color: #333;
  transition: 0.8s;
}

/* Styles pour la section des catégories */
.category {
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
  background-color: transparent;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.category-link {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

h2 {
  color: #333;
  font-size: 24px;
  margin-bottom: 20px;
}

.button-link {
  display: inline-block;
  padding: 10px 20px;
  margin-right: 20px;
  background-color: #447297;
  color: #fff;
  text-decoration: none;
  border-radius: 5px;
  transition: background-color 0.3s ease;
}

.button-link:hover {
  background-color: #333;
 
  transition: 0.5s;
}
h2:hover{
color: antiquewhite;
font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}

.category-image {
  max-width: 200px;
  height: auto;
  margin-bottom: 20px;
}



    </style>