import { createRouter, createWebHashHistory } from 'vue-router'
import Categorie from '../components/Categorie.vue'
import Aboutus from '../components/Aboutus.vue'
import Acceuil from '../components/Acceuil.vue'
import Events from '../components/Events.vue'
import Login from '../components/Login.vue'
import Create from '../components/Create.vue'
import Signup from '../components/Signup.vue'




const routes = [
    // À compléter
    {
      path: '/',
      name : 'Acceuil',
      component:Acceuil
    },
    {
      path: '/aboutus',
      name : 'Aboutus',
      component:Aboutus
    },
    {
      path: '/categories',
      name:'categories',
      component:Categorie
    },
    {
      path: '/events',
      name:'events',
      component:Events
    },
    {
      path: '/login',
      name:'login',
      component:Login
    },
    {
      path: '/signup',
      name:'signup',
      component:Signup
    },
    {
      path: '/create',
      name:'create',
      component:Create
    }
]

const router = createRouter({
    history: createWebHashHistory(),
    routes,
  })

export default router