<script setup>
import { onMounted } from 'vue';

import { useDefaultStore } from './stores/index.js'
import {RouterView} from 'vue-router'
const store = useDefaultStore()

onMounted(() => {
  store.loadData()
  store.loadData2()
})

</script>

<template>
      <header>
    
        
      <img src="../public/image/GoEvent (2)-fotor-bg-remover-20230425215127.png" alt="logomafmch" class="logo">
    
        <nav>
            <ul class="nav_links">
              <li> <router-link to="/" > Acceuil</router-link></li>

              
                    <li> <router-link to="/login" > Login</router-link></li>
                    <li><router-link to="/signup" >Sign-up</router-link></li>

                    <li><router-link to="/create" >Create Event</router-link></li>
                    <li><router-link to="/events" >Events</router-link></li>
                 
                    <li><router-link to="/aboutus" >About Us</router-link></li>

               
            </ul>
        </nav>
      
     
    </header>
  
 <main>
  <div class="content">

 <RouterView/>     
</div>
 </main>
 <footer>
    <div class="footer">
      <div class="footer-content">
        <h3>Find us</h3>

        <ul class="socials">
          <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
          <li><a href="#"><i class="fab fa-youtube"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
        </ul>
      </div>
      <div class="footer-bottom">
        <p>&copy;2023 Designed by <span>Amrou</span></p>
      </div>
    </div>
</footer>

</template>

<style scoped>

@import url(https://use.fontawesome.com/releases/v5.7.2/css/all.css);



header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-right: 100px;
  height: 80px;
  background-color: rgb(28, 27, 27);
}



main {
  padding-top: 80px;
  background-color: #1d1f1e;
}

.content {
  min-height: calc(140vh - 160px); /* Calculating the height of the content area */
}

.logo {
  cursor: pointer;
  order: 2;
  width: 12%;
}

.logo:hover {
  transform: scale(1.1);
  transition: all 0.4s ease 0s;
}

nav {
  order: 1;
}

.nav_links {
  list-style: none;
  display: flex;
}

.nav_links li {
  padding: 0 20px;
}

.nav_links li a {
  font-family: "Montserrat", sans-serif;
  font-weight: bold;
  font-size: 16px;
  color: #edf0f1;
  text-decoration: none;
  transition: all 0.3s ease 0s;
}

.nav_links li a:hover {
  color: #c6d0cc;
  background-color: rgb(80, 142, 212);
  border-radius: 5px;
  padding: 5px 10px;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
  transition: all 0.4s ease 0s;
}

.cta {
  order: 3;
}

.buttcontact {
  padding: 9px 25px;
  background-color: rgba(0, 136, 169, 1);
  border: none;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.3s ease 0s;
}

.buttcontact:hover {
  background-color: rgba(0, 136, 168, 0);
}

footer {
  position: fixed;
  left: 0;
  right: 0;
  background-color: #111111;
  font-family: "Open Sans", sans-serif;
  padding-top: 20px;
  color: #fff;
  bottom: 0;
}

.footer-content {
  background-color: #111111;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  text-align: center;
}

.footer-content h3 {
  background-color: #111111;
  font-size: 1.8rem;
  font-weight: 900;
  text-transform: capitalize;
  line-height: 3rem;
}

.footer-content p {
  max-width: 500px;
  margin: 10px auto;
  line-height: 28px;
  font-size: 14px;
}

.socials {
  background-color: #111111;
  list-style: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1rem 2rem 0rem 0;
}

.fa-search {
  line-height: 40px;
}

.socials li {
  background-color: #111111;
  margin: 0 10px;
}

.socials a {
  background-color: #111111;
  text-decoration: none;
  color: #fff;
}

.socials a i {
  background-color: #111111;
  font-size: 1.1rem;
  transition: color 0.4s ease;
}

.socials a:hover i {
  color: aqua;
}

.footer-bottom {
  background-color: #111111;
  width: 100vw;
  padding: 20px 0;
  text-align: center;
}

.footer-bottom p {
  background-color: #111111;
  font-size: 14px;
  word-spacing: 2px;
  text-transform: capitalize;
}

.footer-bottom span {
  text-transform: uppercase;
  opacity: 0.4;
  font-weight: 200;
}

.footer-space {
  height: 200px; /* Adjust the height as needed */
}

</style>